﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace ExceptionExample.Test.Unit
{
    [TestFixture]
    public class ShipTest
    {

        [Test]
        public void ctor_CorrectParameters_DoesNotThrow()
        {
            Ship uut;
            Assert.DoesNotThrow(() => uut = new Ship(300, 12));
        }

        [Test]
        public void ctor_WrongCourse_Throws()
        {
            Ship uut;
            Assert.Throws<CourseException>(() => uut = new Ship(400, 12));
        }

        [Test]
        public void ctor_WrongSpeed_Throws()
        {
            Ship uut;
            Assert.Throws<SpeedException>(() => uut = new Ship(300, 150));
        }

        [Test]
        public void ctor_WrongSpeed_ThrowsCorrectValue()
        {
            // One method to test the content of the thrown exception
            Ship uut;
            Assert.That(
                () => uut = new Ship(250, 150),
                Throws.TypeOf<SpeedException>().With.Property("Speed").EqualTo(150));
        }

        [Test]
        public void ctor_WrongCourse_ThrowsCorrectValue()
        {
            // Another method to test the content of the thrown exception
            var exc = Assert.Catch<CourseException>(() => new Ship(500, 10));
            Assert.That(exc.Course, Is.EqualTo(500));
        }
    }

}
